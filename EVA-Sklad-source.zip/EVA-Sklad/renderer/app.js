'use strict';
/* =====================================================================
   ЭВА Склад — учёт сырья, меха и производства обуви из ЭВА
   ===================================================================== */

/* ---------- Хранилище ---------- */
const KEY = 'eva_sklad_v1';
const IS_DESKTOP = !!window.api;
const store = IS_DESKTOP
  ? { load: () => window.api.load(), save: t => window.api.save(t) }
  : { load: async () => localStorage.getItem(KEY), save: async t => { localStorage.setItem(KEY, t); } };

function blank() {
  return {
    version: 1, seq: 2,
    rawTypes: [{ id: 1, name: 'ЭВА' }],
    rawColors: [], furColors: [], articles: [],
    rawIn: [], furIn: [], prod: [],
    settings: { company: '', targetDays: 14, avgDays: 14, allowNegative: false }
  };
}
let S = blank();
let saveChain = Promise.resolve();
function save() {
  const text = JSON.stringify(S);
  saveChain = saveChain.then(() => store.save(text)).catch(e => toast('Не удалось сохранить данные: ' + (e && e.message || e), true));
  return saveChain;
}
const nid = () => S.seq++;

/* ---------- Утилиты ---------- */
const $ = s => document.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const byId = (arr, id) => arr.find(x => x.id === +id);
const pad = n => String(n).padStart(2, '0');
const isoOf = d => d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
const today = () => isoOf(new Date());
function addDays(iso, n) { const [y, m, d] = iso.split('-').map(Number); return isoOf(new Date(y, m - 1, d + n)); }
const monthStart = () => today().slice(0, 8) + '01';
function fdate(iso) { if (!iso) return ''; const [y, m, d] = iso.split('-'); return `${d}.${m}.${y}`; }
function parseNum(s) { const t = String(s ?? '').replace(/\s/g, '').replace(',', '.'); return t === '' ? NaN : Number(t); }
const nf = (x, dec = 0) => Number(x).toLocaleString('ru-RU', { minimumFractionDigits: dec, maximumFractionDigits: dec });
const kgOf = g => g / 1000;
function kgTxt(g, dec) { const k = g / 1000; if (dec === undefined) dec = Math.abs(k) >= 100 ? 0 : 1; return nf(k, dec); }
const tTxt = g => nf(g / 1e6, 3);
const MONTHS = ['января', 'февраля', 'марта', 'апреля', 'мая', 'июня', 'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря'];
const longDate = iso => { const [y, m, d] = iso.split('-').map(Number); return `${d} ${MONTHS[m - 1]} ${y}`; };
function plural(n, one, few, many) { const a = Math.abs(n) % 100, b = a % 10; return a > 10 && a < 20 ? many : b > 1 && b < 5 ? few : b === 1 ? one : many; }

let toastTimer;
function toast(msg, bad) {
  const t = $('#toast'); t.textContent = msg; t.className = 'show' + (bad ? ' bad' : '');
  clearTimeout(toastTimer); toastTimer = setTimeout(() => { t.className = ''; }, bad ? 5000 : 2600);
  return false;
}
const active = arr => arr.filter(x => !x.archived);
const rawTypeName = id => byId(S.rawTypes, id)?.name ?? '?';
const multiTypes = () => active(S.rawTypes).length > 1;
const defaultType = () => active(S.rawTypes)[0]?.id ?? S.rawTypes[0]?.id;
function rawColorLabel(typeId, colorId) { const c = byId(S.rawColors, colorId); return (multiTypes() ? rawTypeName(typeId) + ' · ' : '') + (c?.name ?? '?'); }
const articleLabel = id => { const a = byId(S.articles, id); return a ? `${a.code} ${a.name}` : '?'; };
function dot(hex) { return `<i class="dot" style="background:${esc(hex || '#ccc')}"></i>`; }
function rawColorCell(typeId, colorId) { const c = byId(S.rawColors, colorId); return `${dot(c?.hex)}${esc(rawColorLabel(typeId, colorId))}`; }
function furColorCell(id) { if (!id) return '<span class="muted">без меха</span>'; const c = byId(S.furColors, id); return `${dot(c?.hex)}${esc(c?.name ?? '?')}`; }
function opts(arr, sel, label, empty) {
  let h = empty !== undefined ? `<option value="">${esc(empty)}</option>` : '';
  for (const x of arr) h += `<option value="${x.id}"${String(x.id) === String(sel) ? ' selected' : ''}>${esc(label(x))}</option>`;
  return h;
}
function textColor(hex) {
  const h = String(hex || '#888888').replace('#', '');
  const r = parseInt(h.slice(0, 2), 16), g = parseInt(h.slice(2, 4), 16), b = parseInt(h.slice(4, 6), 16);
  return (r * 299 + g * 587 + b * 114) / 1000 > 150 ? '#1A2233' : '#FFFFFF';
}

/* =====================================================================
   Учёт: остатки считаются из документов — поэтому всегда сходятся
   ===================================================================== */
const rkey = (typeId, colorId) => typeId + '|' + colorId;
function rawBalances(asOf) {
  const m = new Map();
  const add = (k, g) => m.set(k, (m.get(k) || 0) + g);
  for (const r of S.rawIn) if (!asOf || r.date <= asOf) add(rkey(r.typeId, r.colorId), r.g);
  for (const p of S.prod) if (!asOf || p.date <= asOf) add(rkey(p.typeId, p.rawColorId), -p.consumeG);
  return m;
}
function furBalances(asOf) {
  const m = new Map();
  const add = (k, n) => m.set(k, (m.get(k) || 0) + n);
  for (const r of S.furIn) if (!asOf || r.date <= asOf) add(r.colorId, r.pairs);
  for (const p of S.prod) if (p.furColorId && (!asOf || p.date <= asOf)) add(p.furColorId, -p.pairs);
  return m;
}
// Средний расход на день производства за последние N дней
function usageStats() {
  const to = today(), from = addDays(to, -(S.settings.avgDays - 1));
  const raw = new Map(), fur = new Map(), days = new Set();
  for (const p of S.prod) {
    if (p.date < from || p.date > to) continue;
    days.add(p.date);
    const k = rkey(p.typeId, p.rawColorId); raw.set(k, (raw.get(k) || 0) + p.consumeG);
    if (p.furColorId) fur.set(p.furColorId, (fur.get(p.furColorId) || 0) + p.pairs);
  }
  return { raw, fur, days: days.size };
}
function statusOf(qty, min, days) {
  if (qty <= 0 || qty < min || (days !== null && days < 3)) return 'crit';
  if (days !== null && days < S.settings.targetDays) return 'warn';
  return 'ok';
}
const ST_TXT = { ok: 'Достаточно', warn: 'Заканчивается', crit: 'Срочно пополнить' };
const ST_CLR = { ok: 'var(--ok)', warn: '#D99A2B', crit: 'var(--crit)' };

function rawPositions(asOf) {
  const bal = rawBalances(asOf), u = usageStats(), live = !asOf || asOf === today();
  const keys = new Set(bal.keys());
  for (const c of active(S.rawColors)) keys.add(rkey(defaultType(), c.id));
  const list = [];
  for (const k of keys) {
    const [typeId, colorId] = k.split('|').map(Number);
    const color = byId(S.rawColors, colorId); if (!color) continue;
    if (color.archived && !(bal.get(k))) continue;
    const g = bal.get(k) || 0, minG = Math.round((color.minKg || 0) * 1000);
    const avg = live && u.days ? (u.raw.get(k) || 0) / u.days : 0;
    const days = avg > 0 ? g / avg : null;
    list.push({ typeId, colorId, color, g, minG, avg, days, status: statusOf(g, minG, days) });
  }
  return list.sort((a, b) => a.typeId - b.typeId || a.color.name.localeCompare(b.color.name, 'ru'));
}
function furPositions(asOf) {
  const bal = furBalances(asOf), u = usageStats(), live = !asOf || asOf === today();
  const list = [];
  for (const c of S.furColors) {
    const n = bal.get(c.id) || 0;
    if (c.archived && !n) continue;
    const avg = live && u.days ? (u.fur.get(c.id) || 0) / u.days : 0;
    const days = avg > 0 ? n / avg : null;
    list.push({ colorId: c.id, color: c, n, min: c.minPairs || 0, avg, days, status: statusOf(n, c.minPairs || 0, days) });
  }
  return list.sort((a, b) => a.color.name.localeCompare(b.color.name, 'ru'));
}

/* ---------- Операции ---------- */
function addRawIn({ date, typeId, colorId, g, supplier, note }) {
  const r = { id: nid(), date, typeId: +typeId, colorId: +colorId, g, supplier: supplier || '', note: note || '', at: Date.now() };
  S.rawIn.push(r); return r;
}
function addFurIn({ date, colorId, pairs, supplier, note }) {
  const r = { id: nid(), date, colorId: +colorId, pairs, supplier: supplier || '', note: note || '', at: Date.now() };
  S.furIn.push(r); return r;
}
function checkProd(f) {
  const errors = [];
  const a = byId(S.articles, f.articleId);
  if (!f.date) errors.push('Укажите дату');
  if (!a) errors.push('Выберите артикул');
  if (!byId(S.rawColors, f.rawColorId)) errors.push('Выберите цвет сырья');
  if (a && a.withFur && !byId(S.furColors, f.furColorId)) errors.push('Выберите цвет меха');
  if (!(f.pairs > 0) || !Number.isInteger(f.pairs)) errors.push('Укажите количество пар');
  if (!(f.gpp > 0)) errors.push('Укажите вес пары в граммах');
  if (errors.length) return { errors };
  const consumeG = Math.round(f.pairs * f.gpp);
  const rawHave = rawBalances().get(rkey(f.typeId, f.rawColorId)) || 0;
  const furId = a.withFur ? +f.furColorId : null;
  const furHave = furId ? (furBalances().get(furId) || 0) : 0;
  const rawShort = consumeG > rawHave, furShort = !!furId && f.pairs > furHave;
  return { errors, consumeG, rawHave, furHave, furId, rawShort, furShort, blocked: !S.settings.allowNegative && (rawShort || furShort) };
}
function addProd(f) {
  const c = checkProd(f);
  if (c.errors.length) return { ok: false, msg: c.errors[0] };
  if (c.blocked) return { ok: false, msg: c.rawShort ? 'Не хватает сырья на складе — сначала внесите поступление' : 'Не хватает меха на складе — сначала внесите поступление' };
  const p = { id: nid(), date: f.date, shift: String(f.shift), articleId: +f.articleId, typeId: +f.typeId, rawColorId: +f.rawColorId,
    furColorId: c.furId, pairs: f.pairs, gpp: f.gpp, consumeG: c.consumeG, at: Date.now() };
  S.prod.push(p);
  return { ok: true, rec: p };
}
// Удаление поступления не должно увести остаток в минус
function canRemoveRawIn(r) {
  if (S.settings.allowNegative) return true;
  return (rawBalances().get(rkey(r.typeId, r.colorId)) || 0) - r.g >= 0;
}
function canRemoveFurIn(r) {
  if (S.settings.allowNegative) return true;
  return (furBalances().get(r.colorId) || 0) - r.pairs >= 0;
}

/* =====================================================================
   Иконки и навигация
   ===================================================================== */
const IC = {
  home: '<path d="M4 11.5 12 5l8 6.5V19a1 1 0 0 1-1 1h-4.5v-5h-5v5H5a1 1 0 0 1-1-1z"/>',
  in: '<path d="M12 4v11M7.5 10.5 12 15l4.5-4.5M5 19h14"/>',
  prod: '<path d="M4 20V10l5 3V10l5 3V6h6v14z"/><path d="M8 17h2M13 17h2"/>',
  stock: '<path d="m12 4 8 4-8 4-8-4z"/><path d="m4 12 8 4 8-4M4 16l8 4 8-4"/>',
  rep: '<path d="M7 3.5h7l4 4V20a.5.5 0 0 1-.5.5h-10A.5.5 0 0 1 7 20z"/><path d="M14 3.5V8h4M10 12h5M10 15.5h5"/>',
  ref: '<path d="M5 5.5A1.5 1.5 0 0 1 6.5 4H19v14H6.5A1.5 1.5 0 0 0 5 19.5z"/><path d="M5 19.5A1.5 1.5 0 0 0 6.5 21H19M9 8h6"/>',
  set: '<circle cx="12" cy="12" r="3"/><path d="M12 3.5v2.2M12 18.3v2.2M3.5 12h2.2M18.3 12h2.2M6 6l1.6 1.6M16.4 16.4 18 18M6 18l1.6-1.6M16.4 7.6 18 6"/>'
};
const icon = (k, s = 20) => `<svg viewBox="0 0 24 24" width="${s}" height="${s}" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${IC[k]}</svg>`;
const PAGES = [['home', 'Главная'], ['in', 'Поступление'], ['prod', 'Производство'], ['stock', 'Остатки'], ['rep', 'Отчёты'], ['ref', 'Справочники'], ['set', 'Настройки']];
let page = 'home';
const VIEWS = {};
function go(p) { page = p; render(); $('#view').scrollTop = 0; }
function render() {
  $('#nav').innerHTML = PAGES.map(([k, l]) => `<button class="${k === page ? 'on' : ''}" data-click="go" data-p="${k}">${icon(k)}<span>${l}</span></button>`).join('');
  $('#company').textContent = S.settings.company || 'учёт сырья и выпуска';
  $('#view').innerHTML = VIEWS[page]();
  const t = today();
  const pairs = S.prod.filter(p => p.date === t).reduce((s, p) => s + p.pairs, 0);
  $('#sideFoot').innerHTML = `${esc(longDate(t))}<br>Сегодня выпущено: <b>${nf(pairs)}</b> пар`;
  if (VIEWS[page].after) VIEWS[page].after();
}

/* ---------- Делегирование событий (без встроенных обработчиков) ---------- */
const ACT = {};
document.addEventListener('click', e => { const el = e.target.closest('[data-click]'); if (el && !el.disabled) ACT[el.dataset.click]?.(el, e); });
document.addEventListener('change', e => { const el = e.target.closest('[data-change]'); if (el) ACT[el.dataset.change]?.(el, e); });
document.addEventListener('input', e => { const el = e.target.closest('[data-input]'); if (el) ACT[el.dataset.input]?.(el, e); });
document.addEventListener('keydown', e => { if (e.key === 'Escape' && $('#modal').innerHTML) closeModal(); });
ACT.go = el => go(el.dataset.p);
$('#shiftBtn').addEventListener('click', () => openShift());

/* =====================================================================
   Главная
   ===================================================================== */
VIEWS.home = () => {
  if (!S.articles.length && !S.rawColors.length) return `<div class="welcome">
    <svg viewBox="0 0 32 32" width="64" height="64" aria-hidden="true"><circle cx="11" cy="12" r="6" fill="#4FC3B5"/><circle cx="21" cy="11" r="5" fill="#F2B84B"/><circle cx="16" cy="21" r="6.5" fill="#E8735A"/></svg>
    <h1>Начнём учёт</h1>
    <p>Добавьте цвета сырья и меха, артикулы с весом пары — и программа будет сама списывать сырьё и мех после каждой смены.</p>
    <div class="actions"><button class="btn pri lg" data-click="go" data-p="ref">Заполнить справочники</button><button class="btn lg" data-click="demo">Посмотреть на примере</button></div></div>`;
  const t = today(), raw = rawPositions(), fur = furPositions();
  const rawG = raw.reduce((s, p) => s + Math.max(0, p.g), 0), furN = fur.reduce((s, p) => s + Math.max(0, p.n), 0);
  const todayPairs = S.prod.filter(p => p.date === t).reduce((s, p) => s + p.pairs, 0);
  const todayKg = S.prod.filter(p => p.date === t).reduce((s, p) => s + p.consumeG, 0);
  const ms = monthStart(), monthPairs = S.prod.filter(p => p.date >= ms && p.date <= t).reduce((s, p) => s + p.pairs, 0);
  const low = [...raw.filter(p => p.status !== 'ok').map(p => ({ kind: 'Сырьё', hex: p.color.hex, name: rawColorLabel(p.typeId, p.colorId), qty: kgTxt(p.g) + ' кг', days: p.days, status: p.status })),
    ...fur.filter(p => p.status !== 'ok').map(p => ({ kind: 'Мех', hex: p.color.hex, name: p.color.name, qty: nf(p.n) + ' пар', days: p.days, status: p.status }))]
    .sort((a, b) => (a.status === 'crit' ? 0 : 1) - (b.status === 'crit' ? 0 : 1) || (a.days ?? 1e9) - (b.days ?? 1e9));
  const ops = [...S.rawIn.map(r => ({ id: r.id, at: r.at || r.id, date: r.date, txt: `Поступило сырьё: ${esc(rawColorLabel(r.typeId, r.colorId))}`, qty: '+' + kgTxt(r.g) + ' кг', hex: byId(S.rawColors, r.colorId)?.hex })),
    ...S.furIn.map(r => ({ id: r.id, at: r.at || r.id, date: r.date, txt: `Поступил мех: ${esc(byId(S.furColors, r.colorId)?.name)}`, qty: '+' + nf(r.pairs) + ' пар', hex: byId(S.furColors, r.colorId)?.hex })),
    ...S.prod.map(p => ({ id: p.id, at: p.at || p.id, date: p.date, txt: `Смена ${esc(p.shift)}: ${esc(articleLabel(p.articleId))}`, qty: nf(p.pairs) + ' пар', hex: byId(S.rawColors, p.rawColorId)?.hex }))]
    .sort((a, b) => b.date.localeCompare(a.date) || b.at - a.at || b.id - a.id).slice(0, 8);
  return `<div class="page-head"><div><h1>${esc(longDate(t))}</h1><p>Остатки и выпуск обновляются сразу после каждой операции.</p></div>
    <button class="btn pri lg" data-click="shift">Закрыть смену</button></div>
  <div class="grid g-kpi">
    <div class="card kpi"><div class="label">Сырьё на складе</div><div class="value">${tTxt(rawG)}<small>т</small></div><div class="hint">${kgTxt(rawG, 0)} кг</div></div>
    <div class="card kpi"><div class="label">Мех на складе</div><div class="value">${nf(furN)}<small>пар</small></div><div class="hint">${fur.length} ${plural(fur.length, 'цвет', 'цвета', 'цветов')}</div></div>
    <div class="card kpi"><div class="label">Выпущено сегодня</div><div class="value">${nf(todayPairs)}<small>пар</small></div><div class="hint">израсходовано ${kgTxt(todayKg)} кг сырья</div></div>
    <div class="card kpi"><div class="label">Выпущено с начала месяца</div><div class="value">${nf(monthPairs)}<small>пар</small></div><div class="hint">с ${fdate(ms)}</div></div>
  </div>
  <div class="grid g-2 mt">
    <div class="card"><div class="card-head"><div><h2>Выпуск за 14 дней</h2><p>Пары обуви по дням</p></div></div><div class="chart">${prodChart()}</div></div>
    <div class="card"><div class="card-head"><div><h2>Требует пополнения</h2><p>Запас меньше ${S.settings.targetDays} дней или ниже минимума</p></div></div>
      ${low.length ? `<table><tbody>${low.slice(0, 8).map(x => `<tr><td>${dot(x.hex)}${esc(x.name)}<br><span class="muted">${x.kind}</span></td><td class="n">${x.qty}<br><span class="muted">${x.days === null ? '' : '≈ ' + nf(x.days, 1) + ' дн.'}</span></td><td><span class="st ${x.status}">${ST_TXT[x.status]}</span></td></tr>`).join('')}</tbody></table>
        ${low.length > 8 ? `<p class="muted">и ещё ${low.length - 8}</p>` : ''}<div class="actions mt"><button class="btn" data-click="go" data-p="stock">Все остатки</button></div>`
      : '<div class="empty">Все позиции в достатке</div>'}</div>
  </div>
  <div class="card mt"><div class="card-head"><h2>Последние операции</h2></div>
    ${ops.length ? `<table><tbody>${ops.map(o => `<tr><td style="width:110px" class="muted">${fdate(o.date)}</td><td>${dot(o.hex)}${o.txt}</td><td class="n">${o.qty}</td></tr>`).join('')}</tbody></table>` : '<div class="empty">Операций пока нет</div>'}</div>`;
};
ACT.shift = () => openShift();
function prodChart() {
  const t = today(), days = [];
  for (let i = 13; i >= 0; i--) { const d = addDays(t, -i); days.push({ d, n: S.prod.filter(p => p.date === d).reduce((s, p) => s + p.pairs, 0) }); }
  const max = Math.max(1, ...days.map(x => x.n));
  const step = (() => { const raw = max / 4, p = Math.pow(10, Math.floor(Math.log10(raw))); return [1, 2, 2.5, 5, 10].map(m => m * p).find(v => v >= raw); })();
  const top = Math.ceil(max / step) * step;
  const W = 700, H = 240, L = 48, B = 26, T = 12, bw = (W - L - 8) / 14;
  const Y = v => T + (H - T - B) * (1 - v / top);
  let s = `<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="Выпуск пар за 14 дней">`;
  for (let v = 0; v <= top; v += step) s += `<line x1="${L}" x2="${W - 4}" y1="${Y(v)}" y2="${Y(v)}" stroke="#E7EBF0"/><text x="${L - 8}" y="${Y(v) + 4}" text-anchor="end">${nf(v)}</text>`;
  days.forEach((x, i) => {
    const x0 = L + i * bw + bw * 0.18, w = bw * 0.64, isT = x.d === t;
    if (x.n) s += `<rect x="${x0}" y="${Y(x.n)}" width="${w}" height="${Y(0) - Y(x.n)}" rx="4" fill="${isT ? '#0F8A7E' : '#9FD3CC'}"><title>${fdate(x.d)}: ${nf(x.n)} пар</title></rect>`;
    s += `<text x="${x0 + w / 2}" y="${H - 8}" text-anchor="middle"${isT ? ' style="fill:#1A2233;font-weight:600"' : ''}>${x.d.slice(8)}.${x.d.slice(5, 7)}</text>`;
  });
  return s + '</svg>';
}

/* =====================================================================
   Закрытие смены (модальное окно)
   ===================================================================== */
let SF = null, lastShift = '1';
function openShift() {
  if (!active(S.articles).length) { go('ref'); return toast('Сначала добавьте артикулы в справочниках', true); }
  if (!active(S.rawColors).length) { go('ref'); return toast('Сначала добавьте цвета сырья в справочниках', true); }
  SF = { date: today(), shift: lastShift, articleId: '', typeId: defaultType(), rawColorId: '', furColorId: '', pairs: '', gpp: '', saveGpp: true, done: [] };
  renderModal();
}
function closeModal() { $('#modal').innerHTML = ''; SF = null; render(); }
function sfData() { return { date: SF.date, shift: SF.shift, articleId: +SF.articleId, typeId: +SF.typeId, rawColorId: +SF.rawColorId, furColorId: +SF.furColorId || null, pairs: parseInt(SF.pairs, 10) || 0, gpp: parseNum(SF.gpp) }; }
function renderModal() {
  if (!SF) return;
  const a = byId(S.articles, SF.articleId);
  const rb = rawBalances(), fb = furBalances();
  const rawSw = active(S.rawColors).map(c => `<button type="button" class="sw${String(c.id) === String(SF.rawColorId) ? ' on' : ''}" data-click="sfRaw" data-id="${c.id}"><i style="background:${esc(c.hex)}"></i><span><b>${esc(c.name)}</b><small>${kgTxt(rb.get(rkey(SF.typeId, c.id)) || 0)} кг</small></span></button>`).join('');
  const furSw = active(S.furColors).map(c => `<button type="button" class="sw${String(c.id) === String(SF.furColorId) ? ' on' : ''}" data-click="sfFur" data-id="${c.id}"><i style="background:${esc(c.hex)}"></i><span><b>${esc(c.name)}</b><small>${nf(fb.get(c.id) || 0)} пар</small></span></button>`).join('');
  const gppChanged = a && SF.gpp !== '' && parseNum(SF.gpp) > 0 && parseNum(SF.gpp) !== a.gpp;
  $('#modal').innerHTML = `<div class="overlay" data-click="overlay"><div class="dialog" role="dialog" aria-modal="true" aria-labelledby="sfTitle">
    <header><h2 id="sfTitle">Закрыть смену</h2><button class="x" data-click="closeModal" aria-label="Закрыть">×</button></header>
    <div class="content">
      ${SF.done.length ? `<div class="done">Проведено в этой смене: ${SF.done.map(d => `${esc(articleLabel(d.articleId))} — ${nf(d.pairs)} пар`).join(', ')}</div>` : ''}
      <div class="fields">
        <label class="field"><span>Дата</span><input type="date" value="${SF.date}" data-change="sf" data-k="date"></label>
        <div class="field"><span>Смена</span><div class="seg">${['1', '2', '3'].map(s => `<button type="button" class="${s === SF.shift ? 'on' : ''}" data-click="sfShift" data-v="${s}">${s}</button>`).join('')}</div></div>
        <label class="field" style="flex:1"><span>Артикул</span><select data-change="sfArticle">${opts(active(S.articles), SF.articleId, x => `${x.code} ${x.name}`, '— выберите артикул —')}</select></label>
      </div>
      ${multiTypes() ? `<label class="field"><span>Вид сырья</span><select data-change="sfType">${opts(active(S.rawTypes), SF.typeId, x => x.name)}</select></label>` : ''}
      <div><div class="step-label">Цвет сырья</div><div class="swatches">${rawSw}</div></div>
      ${a && a.withFur ? `<div><div class="step-label">Цвет меха</div>${furSw ? `<div class="swatches">${furSw}</div>` : '<div class="notice bad">Добавьте цвета меха в справочниках</div>'}</div>`
        : a ? '<div class="muted">Этот артикул без меха — мех не списывается.</div>' : ''}
      <div class="fields">
        <label class="field"><span>Выпущено, пар</span><input class="big num" inputmode="numeric" value="${esc(SF.pairs)}" data-input="sfNum" data-k="pairs" id="sfPairs" placeholder="0"></label>
        <label class="field"><span>Вес одной пары, г</span><input class="big num" inputmode="decimal" value="${esc(SF.gpp)}" data-input="sfNum" data-k="gpp" id="sfGpp" placeholder="0" ${a ? '' : 'disabled'}></label>
        <label class="check" id="sfSaveGpp" style="margin-bottom:14px;${gppChanged ? '' : 'visibility:hidden'}"><input type="checkbox" ${SF.saveGpp ? 'checked' : ''} data-change="sfSaveGpp"> Запомнить новый вес для артикула (было ${a ? nf(a.gpp, a.gpp % 1 ? 1 : 0) : ''} г)</label>
      </div>
      <div id="sfSummary">${sfSummary()}</div>
    </div>
    <footer><button class="btn" data-click="closeModal">${SF.done.length ? 'Готово' : 'Отмена'}</button><button class="btn pri lg" id="sfPost" data-click="sfPost">Провести и списать</button></footer>
  </div></div>`;
  updatePostBtn();
}
function sfSummary() {
  const f = sfData(), a = byId(S.articles, f.articleId);
  if (!a || !f.rawColorId || !(f.pairs > 0) || !(f.gpp > 0)) return '<div class="summary"><div class="muted">Выберите артикул, цвета и введите количество пар — здесь появится расчёт списания.</div></div>';
  const c = checkProd(f);
  if (c.errors.length) return `<div class="summary"><div class="muted">${esc(c.errors[0])}</div></div>`;
  const rc = byId(S.rawColors, f.rawColorId), fc = c.furId ? byId(S.furColors, c.furId) : null;
  let h = `<div class="summary">
    <div class="line${c.rawShort ? ' bad' : ''}">${dot(rc.hex)}<span class="what">Сырьё ${esc(rawColorLabel(f.typeId, f.rawColorId))}<div class="after">${nf(f.pairs)} пар × ${nf(f.gpp, f.gpp % 1 ? 1 : 0)} г · останется ${kgTxt(c.rawHave - c.consumeG, 1)} кг</div></span><b>−${kgTxt(c.consumeG, 1)} кг</b></div>`;
  if (fc) h += `<div class="line${c.furShort ? ' bad' : ''}">${dot(fc.hex)}<span class="what">Мех ${esc(fc.name)}<div class="after">1 пара меха на пару обуви · останется ${nf(c.furHave - f.pairs)} пар</div></span><b>−${nf(f.pairs)} пар</b></div>`;
  h += '</div>';
  if (c.rawShort || c.furShort) h += `<div class="notice bad" style="margin-top:10px">${c.rawShort ? `Сырья не хватает: нужно ${kgTxt(c.consumeG, 1)} кг, на складе ${kgTxt(c.rawHave, 1)} кг. ` : ''}${c.furShort ? `Меха не хватает: нужно ${nf(f.pairs)} пар, на складе ${nf(c.furHave)}. ` : ''}${S.settings.allowNegative ? 'Остаток станет отрицательным.' : 'Внесите поступление или включите в настройках проведение в минус.'}</div>`;
  return h;
}
function updatePostBtn() {
  const b = $('#sfPost'); if (!b) return;
  const f = sfData(), c = checkProd(f);
  b.disabled = !!c.errors.length || c.blocked;
}
ACT.overlay = (el, e) => { if (e.target === el) closeModal(); };
ACT.closeModal = () => closeModal();
ACT.sf = el => { SF[el.dataset.k] = el.value; renderModal(); };
ACT.sfShift = el => { SF.shift = el.dataset.v; renderModal(); };
ACT.sfType = el => { SF.typeId = el.value; renderModal(); };
ACT.sfArticle = el => {
  SF.articleId = el.value; const a = byId(S.articles, el.value);
  SF.gpp = a ? String(a.gpp).replace('.', ',') : ''; SF.saveGpp = true;
  if (a && !a.withFur) SF.furColorId = '';
  renderModal(); if (a) $('#sfPairs')?.focus();
};
ACT.sfRaw = el => { SF.rawColorId = el.dataset.id; renderModal(); };
ACT.sfFur = el => { SF.furColorId = el.dataset.id; renderModal(); };
ACT.sfSaveGpp = el => { SF.saveGpp = el.checked; };
ACT.sfNum = el => {
  SF[el.dataset.k] = el.value;
  $('#sfSummary').innerHTML = sfSummary();
  const a = byId(S.articles, SF.articleId), g = parseNum(SF.gpp);
  const lab = $('#sfSaveGpp'); if (lab) lab.style.visibility = a && g > 0 && g !== a.gpp ? 'visible' : 'hidden';
  updatePostBtn();
};
ACT.sfPost = () => {
  const f = sfData(), a = byId(S.articles, f.articleId);
  const res = addProd(f);
  if (!res.ok) return toast(res.msg, true);
  if (a && SF.saveGpp && f.gpp !== a.gpp) a.gpp = f.gpp;
  save(); lastShift = SF.shift;
  SF.done.push(res.rec);
  toast(`Проведено: ${articleLabel(res.rec.articleId)}, ${nf(res.rec.pairs)} пар, списано ${kgTxt(res.rec.consumeG, 1)} кг сырья${res.rec.furColorId ? ' и ' + nf(res.rec.pairs) + ' пар меха' : ''}`);
  Object.assign(SF, { articleId: '', rawColorId: '', furColorId: '', pairs: '', gpp: '', saveGpp: true });
  renderModal(); render();
};

/* =====================================================================
   Поступление
   ===================================================================== */
const IN = { tab: 'raw', date: today(), typeId: '', colorId: '', qty: '', unit: 't', supplier: '', note: '', from: monthStart(), to: today() };
VIEWS.in = () => {
  if (!IN.typeId) IN.typeId = defaultType();
  const isRaw = IN.tab === 'raw';
  const colors = active(isRaw ? S.rawColors : S.furColors);
  const rb = rawBalances(), fb = furBalances();
  const sw = colors.map(c => `<button type="button" class="sw${String(c.id) === String(IN.colorId) ? ' on' : ''}" data-click="inColor" data-id="${c.id}"><i style="background:${esc(c.hex)}"></i><span><b>${esc(c.name)}</b><small>${isRaw ? kgTxt(rb.get(rkey(IN.typeId, c.id)) || 0) + ' кг' : nf(fb.get(c.id) || 0) + ' пар'}</small></span></button>`).join('');
  const suppliers = [...new Set([...S.rawIn, ...S.furIn].map(r => r.supplier).filter(Boolean))];
  const list = (isRaw ? S.rawIn : S.furIn).filter(r => r.date >= IN.from && r.date <= IN.to).sort((a, b) => b.date.localeCompare(a.date) || b.id - a.id);
  const total = list.reduce((s, r) => s + (isRaw ? r.g : r.pairs), 0);
  return `<div class="page-head"><div><h1>Поступление</h1><p>Приём сырья в тоннах и меха в парах — по цветам.</p></div>
    <div class="seg"><button class="${isRaw ? 'on' : ''}" data-click="inTab" data-v="raw">Сырьё</button><button class="${!isRaw ? 'on' : ''}" data-click="inTab" data-v="fur">Мех</button></div></div>
  <div class="card">
    <div class="card-head"><h2>${isRaw ? 'Принять сырьё' : 'Принять мех'}</h2></div>
    <div class="fields">
      <label class="field"><span>Дата</span><input type="date" value="${IN.date}" data-change="inSet" data-k="date"></label>
      ${isRaw && multiTypes() ? `<label class="field"><span>Вид сырья</span><select data-change="inType">${opts(active(S.rawTypes), IN.typeId, x => x.name)}</select></label>` : ''}
      <label class="field"><span>Поставщик</span><input class="w-l" list="supList" value="${esc(IN.supplier)}" data-input="inSet" data-k="supplier"><datalist id="supList">${suppliers.map(s => `<option value="${esc(s)}">`).join('')}</datalist></label>
      <label class="field" style="flex:1"><span>Примечание</span><input value="${esc(IN.note)}" data-input="inSet" data-k="note" placeholder="№ накладной, номер машины…"></label>
    </div>
    <div class="mt"><div class="step-label">Цвет ${isRaw ? 'сырья' : 'меха'}</div>${sw ? `<div class="swatches">${sw}</div>` : `<div class="notice bad">Добавьте цвета ${isRaw ? 'сырья' : 'меха'} в справочниках</div>`}</div>
    <div class="fields mt">
      <label class="field"><span>Количество</span><input class="big num" id="inQty" inputmode="decimal" value="${esc(IN.qty)}" data-input="inQty" placeholder="0"></label>
      ${isRaw ? `<div class="field"><span>Единица</span><div class="seg"><button class="${IN.unit === 't' ? 'on' : ''}" data-click="inUnit" data-v="t">тонны</button><button class="${IN.unit === 'kg' ? 'on' : ''}" data-click="inUnit" data-v="kg">кг</button></div></div>` : '<div class="field"><span>Единица</span><div style="padding:12px 0" class="muted">пар</div></div>'}
      <div class="field" style="flex:1"><span>&nbsp;</span><div class="muted" id="inHint" style="padding:12px 0">${inHint()}</div></div>
      <button class="btn pri lg" data-click="inPost">Принять на склад</button>
    </div>
  </div>
  <div class="card"><div class="card-head"><div><h2>Принято за период</h2><p>Всего: <b>${isRaw ? tTxt(total) + ' т (' + kgTxt(total, 0) + ' кг)' : nf(total) + ' пар'}</b></p></div>
    <div class="fields"><label class="field"><span>с</span><input type="date" value="${IN.from}" data-change="inPeriod" data-k="from"></label><label class="field"><span>по</span><input type="date" value="${IN.to}" data-change="inPeriod" data-k="to"></label></div></div>
    ${list.length ? `<div class="tbl-wrap"><table><thead><tr><th>Дата</th><th>Цвет</th><th class="n">${isRaw ? 'Кг' : 'Пар'}</th>${isRaw ? '<th class="n">Тонн</th>' : ''}<th>Поставщик</th><th>Примечание</th><th></th></tr></thead><tbody>
      ${list.map(r => `<tr><td>${fdate(r.date)}</td><td>${isRaw ? rawColorCell(r.typeId, r.colorId) : furColorCell(r.colorId)}</td><td class="n">${isRaw ? kgTxt(r.g, 1) : nf(r.pairs)}</td>${isRaw ? `<td class="n">${tTxt(r.g)}</td>` : ''}<td>${esc(r.supplier)}</td><td class="muted">${esc(r.note)}</td><td class="n"><button class="link danger" data-click="inDel" data-id="${r.id}">удалить</button></td></tr>`).join('')}
    </tbody></table></div>` : '<div class="empty">За этот период поступлений нет</div>'}</div>`;
};
function inHint() {
  const q = parseNum(IN.qty);
  if (!(q > 0)) return '';
  if (IN.tab === 'raw') return IN.unit === 't' ? `= ${nf(q * 1000, q * 1000 % 1 ? 1 : 0)} кг` : `= ${nf(q / 1000, 3)} т`;
  return '';
}
ACT.inTab = el => { IN.tab = el.dataset.v; IN.colorId = ''; IN.qty = ''; render(); };
ACT.inSet = el => { IN[el.dataset.k] = el.value; };
ACT.inType = el => { IN.typeId = el.value; render(); };
ACT.inColor = el => { IN.colorId = el.dataset.id; render(); $('#inQty')?.focus(); };
ACT.inUnit = el => { IN.unit = el.dataset.v; render(); };
ACT.inQty = el => { IN.qty = el.value; $('#inHint').textContent = inHint(); };
ACT.inPeriod = el => { IN[el.dataset.k] = el.value; render(); };
ACT.inPost = () => {
  if (!IN.date) return toast('Укажите дату', true);
  if (!IN.colorId) return toast('Выберите цвет', true);
  const q = parseNum(IN.qty);
  if (!(q > 0)) return toast('Укажите количество', true);
  if (IN.tab === 'raw') {
    const g = Math.round(IN.unit === 't' ? q * 1e6 : q * 1000);
    if (g > 1e9) return toast('Слишком большое количество — проверьте единицы', true);
    addRawIn({ date: IN.date, typeId: IN.typeId, colorId: IN.colorId, g, supplier: IN.supplier.trim(), note: IN.note.trim() });
    toast(`Принято ${kgTxt(g, 1)} кг сырья: ${rawColorLabel(IN.typeId, IN.colorId)}`);
  } else {
    if (!Number.isInteger(q)) return toast('Количество пар — целое число', true);
    addFurIn({ date: IN.date, colorId: IN.colorId, pairs: q, supplier: IN.supplier.trim(), note: IN.note.trim() });
    toast(`Принято ${nf(q)} пар меха: ${byId(S.furColors, IN.colorId).name}`);
  }
  save(); IN.qty = ''; IN.note = ''; IN.colorId = ''; render();
};
ACT.inDel = el => {
  const id = +el.dataset.id, isRaw = IN.tab === 'raw';
  const r = byId(isRaw ? S.rawIn : S.furIn, id); if (!r) return;
  if (!(isRaw ? canRemoveRawIn(r) : canRemoveFurIn(r))) return toast('Нельзя удалить: этот материал уже израсходован, остаток станет отрицательным', true);
  if (!confirm('Удалить запись о поступлении? Остаток уменьшится.')) return;
  if (isRaw) S.rawIn = S.rawIn.filter(x => x.id !== id); else S.furIn = S.furIn.filter(x => x.id !== id);
  save(); render(); toast('Поступление удалено');
};

/* =====================================================================
   Производство
   ===================================================================== */
const PR = { from: addDays(today(), -6), to: today(), articleId: '' };
VIEWS.prod = () => {
  const list = S.prod.filter(p => p.date >= PR.from && p.date <= PR.to && (!PR.articleId || p.articleId === +PR.articleId))
    .sort((a, b) => b.date.localeCompare(a.date) || a.shift.localeCompare(b.shift) || a.id - b.id);
  const pairs = list.reduce((s, p) => s + p.pairs, 0), g = list.reduce((s, p) => s + p.consumeG, 0), fur = list.reduce((s, p) => s + (p.furColorId ? p.pairs : 0), 0);
  let rows = '', lastKey = '';
  for (const p of list) {
    const k = p.date + '|' + p.shift;
    if (k !== lastKey) {
      const grp = list.filter(x => x.date === p.date && x.shift === p.shift);
      rows += `<tr class="section"><td colspan="5">${fdate(p.date)}, смена ${esc(p.shift)}</td><td class="n">${nf(grp.reduce((s, x) => s + x.pairs, 0))}</td><td></td><td class="n">${kgTxt(grp.reduce((s, x) => s + x.consumeG, 0), 1)}</td><td></td></tr>`;
      lastKey = k;
    }
    rows += `<tr><td></td><td>${esc(articleLabel(p.articleId))}</td><td>${rawColorCell(p.typeId, p.rawColorId)}</td><td>${furColorCell(p.furColorId)}</td><td></td><td class="n">${nf(p.pairs)}</td><td class="n">${nf(p.gpp, p.gpp % 1 ? 1 : 0)}</td><td class="n">${kgTxt(p.consumeG, 1)}</td><td class="n"><button class="link danger" data-click="prodDel" data-id="${p.id}">удалить</button></td></tr>`;
  }
  return `<div class="page-head"><div><h1>Производство</h1><p>Выпуск по сменам и списанные сырьё и мех.</p></div><button class="btn pri lg" data-click="shift">Закрыть смену</button></div>
  <div class="grid g-kpi">
    <div class="card kpi"><div class="label">Выпущено за период</div><div class="value">${nf(pairs)}<small>пар</small></div></div>
    <div class="card kpi"><div class="label">Израсходовано сырья</div><div class="value">${kgTxt(g, 0)}<small>кг</small></div><div class="hint">${tTxt(g)} т</div></div>
    <div class="card kpi"><div class="label">Израсходовано меха</div><div class="value">${nf(fur)}<small>пар</small></div></div>
    <div class="card kpi"><div class="label">Средний вес пары</div><div class="value">${pairs ? nf(g / pairs, 0) : '—'}<small>г</small></div></div>
  </div>
  <div class="card mt"><div class="card-head"><h2>Смены</h2>
    <div class="fields"><label class="field"><span>с</span><input type="date" value="${PR.from}" data-change="prSet" data-k="from"></label><label class="field"><span>по</span><input type="date" value="${PR.to}" data-change="prSet" data-k="to"></label>
    <label class="field"><span>Артикул</span><select data-change="prSet" data-k="articleId">${opts(S.articles, PR.articleId, x => x.code + ' ' + x.name, 'Все')}</select></label></div></div>
    ${list.length ? `<div class="tbl-wrap"><table><thead><tr><th></th><th>Артикул</th><th>Цвет сырья</th><th>Цвет меха</th><th></th><th class="n">Пар</th><th class="n">Вес пары, г</th><th class="n">Сырьё, кг</th><th></th></tr></thead><tbody>${rows}</tbody>
      <tfoot><tr><td colspan="5">Итого</td><td class="n">${nf(pairs)}</td><td></td><td class="n">${kgTxt(g, 1)}</td><td></td></tr></tfoot></table></div>`
    : '<div class="empty">За этот период смен нет. Нажмите «Закрыть смену», чтобы внести выпуск.</div>'}</div>`;
};
ACT.prSet = el => { PR[el.dataset.k] = el.value; render(); };
ACT.prodDel = el => {
  const id = +el.dataset.id, p = byId(S.prod, id); if (!p) return;
  if (!confirm(`Удалить запись: ${articleLabel(p.articleId)}, ${nf(p.pairs)} пар? Списанное сырьё и мех вернутся на склад.`)) return;
  S.prod = S.prod.filter(x => x.id !== id); save(); render(); toast('Запись удалена, остатки восстановлены');
};

/* =====================================================================
   Остатки
   ===================================================================== */
const ST = { tab: 'raw', date: today() };
VIEWS.stock = () => {
  const isRaw = ST.tab === 'raw', live = ST.date === today();
  const pos = isRaw ? rawPositions(ST.date) : furPositions(ST.date);
  const target = S.settings.targetDays;
  const tiles = pos.map(p => {
    const qty = isRaw ? p.g : p.n, min = isRaw ? p.minG : p.min;
    const fill = p.days !== null ? Math.min(1, p.days / (target * 2)) : min > 0 ? Math.min(1, Math.max(0, qty) / (min * 3)) : (qty > 0 ? 1 : 0);
    return `<div class="tile ${live ? p.status : ''}"><div class="chip" style="background:${esc(p.color.hex)}">${isRaw && multiTypes() ? `<span>${esc(rawTypeName(p.typeId))}</span>` : ''}</div><div class="body">
      <div class="name">${esc(p.color.name)}</div>
      <div class="qty${qty < 0 ? ' neg' : ''}">${isRaw ? kgTxt(qty, 0) : nf(qty)}<small>${isRaw ? 'кг' : 'пар'}</small></div>
      <div class="sub">${isRaw ? tTxt(qty) + ' т' : '&nbsp;'}${live && p.days !== null ? ` · хватит ≈ ${nf(p.days, 1)} дн.` : ''}</div>
      ${live ? `<div class="bar"><i style="width:${Math.round(fill * 100)}%;background:${ST_CLR[p.status]}"></i></div><div style="margin-top:8px"><span class="st ${p.status}">${ST_TXT[p.status]}</span></div>` : ''}
    </div></div>`;
  }).join('');
  const total = pos.reduce((s, p) => s + (isRaw ? p.g : p.n), 0);
  return `<div class="page-head"><div><h1>Остатки</h1><p>${live ? 'Сейчас на складе — с учётом всех поступлений и смен.' : 'На конец дня ' + fdate(ST.date) + '.'}</p></div>
    <div class="actions"><label class="field"><span>На дату</span><input type="date" value="${ST.date}" data-change="stSet" data-k="date"></label>
    <div class="field"><span>&nbsp;</span><div class="seg"><button class="${isRaw ? 'on' : ''}" data-click="stTab" data-v="raw">Сырьё</button><button class="${!isRaw ? 'on' : ''}" data-click="stTab" data-v="fur">Мех</button></div></div></div></div>
  <div class="card" style="margin-bottom:18px"><div class="actions"><div><div class="muted">Всего ${isRaw ? 'сырья' : 'меха'}</div><div style="font:600 24px var(--font-d)">${isRaw ? tTxt(total) + ' т · ' + kgTxt(total, 0) + ' кг' : nf(total) + ' пар'}</div></div><span class="spacer"></span>
    <button class="btn" data-click="stReport">Отчёт по остаткам</button></div></div>
  ${pos.length ? `<div class="tiles">${tiles}</div>` : `<div class="card empty">Цветов ${isRaw ? 'сырья' : 'меха'} пока нет — добавьте их в справочниках</div>`}
  ${pos.length && live ? `<div class="card mt"><div class="card-head"><div><h2>Подробно</h2><p>Средний расход — за последние ${S.settings.avgDays} дн., на один день выпуска</p></div></div><table><thead><tr><th>Цвет</th><th class="n">Остаток</th><th class="n">Минимум</th><th class="n">Расход в день</th><th class="n">Хватит, дн.</th><th>Состояние</th></tr></thead><tbody>
    ${pos.map(p => `<tr><td>${isRaw ? rawColorCell(p.typeId, p.colorId) : furColorCell(p.colorId)}</td><td class="n${(isRaw ? p.g : p.n) < 0 ? ' neg' : ''}">${isRaw ? kgTxt(p.g, 1) + ' кг' : nf(p.n) + ' пар'}</td><td class="n">${isRaw ? (p.minG ? kgTxt(p.minG, 0) + ' кг' : '—') : (p.min ? nf(p.min) + ' пар' : '—')}</td><td class="n">${p.avg ? (isRaw ? kgTxt(p.avg, 1) + ' кг' : nf(p.avg, 0) + ' пар') : '—'}</td><td class="n">${p.days === null ? '—' : nf(p.days, 1)}</td><td><span class="st ${p.status}">${ST_TXT[p.status]}</span></td></tr>`).join('')}</tbody></table></div>` : ''}`;
};
ACT.stTab = el => { ST.tab = el.dataset.v; render(); };
ACT.stSet = el => { ST.date = el.value || today(); render(); };
ACT.stReport = () => { REP.id = 'stock'; REP.date = ST.date; go('rep'); };

/* =====================================================================
   Отчёты (просмотр, PDF, Excel)
   ===================================================================== */
const REP = { id: 'rawMove', from: monthStart(), to: today(), date: today() };
const REPORTS = [
  { id: 'rawMove', title: 'Движение сырья', desc: 'Остаток на начало, приход, расход, остаток на конец', period: true },
  { id: 'furMove', title: 'Движение меха', desc: 'То же по меху, в парах', period: true },
  { id: 'prod', title: 'Производство по сменам', desc: 'Каждая смена: артикул, цвета, пары, сырьё', period: true, landscape: true },
  { id: 'byArticle', title: 'Итоги по артикулам', desc: 'Сколько пар каждого артикула и сколько ушло сырья и меха', period: true },
  { id: 'receipts', title: 'Поступления', desc: 'Все приходы сырья и меха за период', period: true, landscape: true },
  { id: 'stock', title: 'Остатки на дату', desc: 'Сырьё и мех на конец выбранного дня', period: false }
];
// Колонки: t = 'text' | 'kg' (граммы → кг) | 'int' | 'g' (граммы на пару)
function buildReport(id) {
  const def = REPORTS.find(r => r.id === id), from = REP.from, to = REP.to;
  const R = { title: def.title, period: def.period ? `за период с ${fdate(from)} по ${fdate(to)}` : `на конец дня ${fdate(REP.date)}`, landscape: !!def.landscape, cols: [], rows: [], total: null };
  if (id === 'rawMove') {
    R.cols = [{ h: 'Вид сырья', t: 'text', w: 14 }, { h: 'Цвет', t: 'text', w: 18 }, { h: 'Остаток на начало, кг', t: 'kg', w: 16 }, { h: 'Поступило, кг', t: 'kg', w: 14 }, { h: 'Израсходовано, кг', t: 'kg', w: 16 }, { h: 'Остаток на конец, кг', t: 'kg', w: 16 }];
    const start = rawBalances(addDays(from, -1)), keys = new Set(start.keys()), inc = new Map(), out = new Map();
    for (const r of S.rawIn) if (r.date >= from && r.date <= to) { const k = rkey(r.typeId, r.colorId); inc.set(k, (inc.get(k) || 0) + r.g); keys.add(k); }
    for (const p of S.prod) if (p.date >= from && p.date <= to) { const k = rkey(p.typeId, p.rawColorId); out.set(k, (out.get(k) || 0) + p.consumeG); keys.add(k); }
    const tot = [0, 0, 0, 0];
    [...keys].map(k => k.split('|').map(Number)).sort((a, b) => a[0] - b[0] || (byId(S.rawColors, a[1])?.name || '').localeCompare(byId(S.rawColors, b[1])?.name || '', 'ru')).forEach(([t, c]) => {
      const k = rkey(t, c), s = start.get(k) || 0, i = inc.get(k) || 0, o = out.get(k) || 0, e = s + i - o;
      R.rows.push([rawTypeName(t), byId(S.rawColors, c)?.name, s, i, o, e]); tot[0] += s; tot[1] += i; tot[2] += o; tot[3] += e;
    });
    R.total = ['Итого', '', ...tot];
    if (!multiTypes()) { R.cols.shift(); R.rows = R.rows.map(r => r.slice(1)); R.total = ['Итого', ...tot]; R.cols[0].w = 22; }
  }
  if (id === 'furMove') {
    R.cols = [{ h: 'Цвет меха', t: 'text', w: 20 }, { h: 'Остаток на начало, пар', t: 'int', w: 18 }, { h: 'Поступило, пар', t: 'int', w: 15 }, { h: 'Израсходовано, пар', t: 'int', w: 17 }, { h: 'Остаток на конец, пар', t: 'int', w: 18 }];
    const start = furBalances(addDays(from, -1)), ids = new Set(start.keys()), inc = new Map(), out = new Map();
    for (const r of S.furIn) if (r.date >= from && r.date <= to) { inc.set(r.colorId, (inc.get(r.colorId) || 0) + r.pairs); ids.add(r.colorId); }
    for (const p of S.prod) if (p.furColorId && p.date >= from && p.date <= to) { out.set(p.furColorId, (out.get(p.furColorId) || 0) + p.pairs); ids.add(p.furColorId); }
    const tot = [0, 0, 0, 0];
    [...ids].sort((a, b) => (byId(S.furColors, a)?.name || '').localeCompare(byId(S.furColors, b)?.name || '', 'ru')).forEach(c => {
      const s = start.get(c) || 0, i = inc.get(c) || 0, o = out.get(c) || 0, e = s + i - o;
      R.rows.push([byId(S.furColors, c)?.name, s, i, o, e]); tot[0] += s; tot[1] += i; tot[2] += o; tot[3] += e;
    });
    R.total = ['Итого', ...tot];
  }
  if (id === 'prod') {
    R.cols = [{ h: 'Дата', t: 'text', w: 11 }, { h: 'Смена', t: 'text', w: 7 }, { h: 'Артикул', t: 'text', w: 26 }, { h: 'Цвет сырья', t: 'text', w: 16 }, { h: 'Цвет меха', t: 'text', w: 14 }, { h: 'Пар', t: 'int', w: 9 }, { h: 'Вес пары, г', t: 'g', w: 11 }, { h: 'Сырьё, кг', t: 'kg', w: 12 }];
    const list = S.prod.filter(p => p.date >= from && p.date <= to).sort((a, b) => a.date.localeCompare(b.date) || a.shift.localeCompare(b.shift) || a.id - b.id);
    for (const p of list) R.rows.push([fdate(p.date), p.shift, articleLabel(p.articleId), rawColorLabel(p.typeId, p.rawColorId), p.furColorId ? byId(S.furColors, p.furColorId)?.name : '—', p.pairs, p.gpp, p.consumeG]);
    R.total = ['Итого', '', '', '', '', list.reduce((s, p) => s + p.pairs, 0), '', list.reduce((s, p) => s + p.consumeG, 0)];
  }
  if (id === 'byArticle') {
    R.cols = [{ h: 'Артикул', t: 'text', w: 12 }, { h: 'Наименование', t: 'text', w: 26 }, { h: 'Выпущено, пар', t: 'int', w: 14 }, { h: 'Сырьё, кг', t: 'kg', w: 13 }, { h: 'Мех, пар', t: 'int', w: 11 }, { h: 'Средний вес пары, г', t: 'g', w: 17 }];
    const m = new Map();
    for (const p of S.prod) if (p.date >= from && p.date <= to) { const x = m.get(p.articleId) || { pairs: 0, g: 0, fur: 0 }; x.pairs += p.pairs; x.g += p.consumeG; x.fur += p.furColorId ? p.pairs : 0; m.set(p.articleId, x); }
    const tot = { pairs: 0, g: 0, fur: 0 };
    [...m.entries()].sort((a, b) => (byId(S.articles, a[0])?.code || '').localeCompare(byId(S.articles, b[0])?.code || '', 'ru')).forEach(([aid, x]) => {
      const a = byId(S.articles, aid); R.rows.push([a?.code, a?.name, x.pairs, x.g, x.fur, Math.round(x.g / x.pairs * 10) / 10]);
      tot.pairs += x.pairs; tot.g += x.g; tot.fur += x.fur;
    });
    R.total = ['Итого', '', tot.pairs, tot.g, tot.fur, tot.pairs ? Math.round(tot.g / tot.pairs * 10) / 10 : ''];
  }
  if (id === 'receipts') {
    R.cols = [{ h: 'Дата', t: 'text', w: 11 }, { h: 'Что', t: 'text', w: 10 }, { h: 'Цвет', t: 'text', w: 18 }, { h: 'Сырьё, кг', t: 'kg', w: 13 }, { h: 'Мех, пар', t: 'int', w: 11 }, { h: 'Поставщик', t: 'text', w: 24 }, { h: 'Примечание', t: 'text', w: 26 }];
    const list = [...S.rawIn.filter(r => r.date >= from && r.date <= to).map(r => ({ r, raw: true })), ...S.furIn.filter(r => r.date >= from && r.date <= to).map(r => ({ r, raw: false }))]
      .sort((a, b) => a.r.date.localeCompare(b.r.date) || a.r.id - b.r.id);
    let g = 0, n = 0;
    for (const { r, raw } of list) {
      R.rows.push([fdate(r.date), raw ? 'Сырьё' : 'Мех', raw ? rawColorLabel(r.typeId, r.colorId) : byId(S.furColors, r.colorId)?.name, raw ? r.g : '', raw ? '' : r.pairs, r.supplier, r.note]);
      if (raw) g += r.g; else n += r.pairs;
    }
    R.total = ['Итого', '', '', g, n, '', ''];
  }
  if (id === 'stock') {
    R.cols = [{ h: 'Позиция', t: 'text', w: 26 }, { h: 'Остаток, кг', t: 'kg', w: 15 }, { h: 'Остаток, т', t: 'text', w: 12 }, { h: 'Остаток, пар', t: 'int', w: 14 }];
    const raw = rawPositions(REP.date), fur = furPositions(REP.date);
    R.rows.push({ section: 'Сырьё' });
    for (const p of raw) R.rows.push([rawColorLabel(p.typeId, p.colorId), p.g, tTxt(p.g), '']);
    R.rows.push({ section: 'Мех' });
    for (const p of fur) R.rows.push([p.color.name, '', '', p.n]);
    const rg = raw.reduce((s, p) => s + p.g, 0);
    R.total = ['Итого', rg, tTxt(rg), fur.reduce((s, p) => s + p.n, 0)];
  }
  return R;
}
function cellTxt(v, t) {
  if (v === '' || v === null || v === undefined) return '';
  if (t === 'kg') return nf(v / 1000, 1);
  if (t === 'int') return nf(v);
  if (t === 'g') return nf(v, v % 1 ? 1 : 0);
  return esc(v);
}
function reportTable(R) {
  const num = t => t !== 'text';
  return `<table><thead><tr>${R.cols.map(c => `<th class="${num(c.t) ? 'n' : ''}">${esc(c.h)}</th>`).join('')}</tr></thead><tbody>
    ${R.rows.length ? R.rows.map(r => r.section ? `<tr class="section"><td colspan="${R.cols.length}">${esc(r.section)}</td></tr>` : `<tr>${r.map((v, i) => `<td class="${num(R.cols[i].t) ? 'n' : ''}">${cellTxt(v, R.cols[i].t)}</td>`).join('')}</tr>`).join('')
      : `<tr><td colspan="${R.cols.length}" class="empty">Нет данных за выбранный период</td></tr>`}
  </tbody>${R.total && R.rows.length ? `<tfoot><tr>${R.total.map((v, i) => `<td class="${num(R.cols[i].t) ? 'n' : ''}">${cellTxt(v, R.cols[i].t)}</td>`).join('')}</tr></tfoot>` : ''}</table>`;
}
VIEWS.rep = () => {
  const def = REPORTS.find(r => r.id === REP.id), R = buildReport(REP.id);
  return `<div class="page-head"><div><h1>Отчёты</h1><p>Выберите отчёт и период, затем сохраните его в PDF или Excel.</p></div></div>
  <div class="rep-layout">
    <div class="rep-list">${REPORTS.map(r => `<button class="${r.id === REP.id ? 'on' : ''}" data-click="repSel" data-id="${r.id}"><b>${r.title}</b><small>${r.desc}</small></button>`).join('')}</div>
    <div class="card">
      <div class="card-head"><div><h2>${def.title}</h2><p>${R.period}</p></div>
        <div class="actions">
          ${def.period ? `<label class="field"><span>с</span><input type="date" value="${REP.from}" data-change="repSet" data-k="from"></label><label class="field"><span>по</span><input type="date" value="${REP.to}" data-change="repSet" data-k="to"></label>`
            : `<label class="field"><span>На дату</span><input type="date" value="${REP.date}" data-change="repSet" data-k="date"></label>`}
          <div class="field"><span>&nbsp;</span><div class="actions"><button class="btn" data-click="repPdf">Сохранить PDF</button><button class="btn pri" data-click="repXlsx">Сохранить Excel</button></div></div>
        </div></div>
      <div class="rep-preview">${reportTable(R)}</div>
    </div>
  </div>`;
};
ACT.repSel = el => { REP.id = el.dataset.id; render(); };
ACT.repSet = el => { if (el.value) REP[el.dataset.k] = el.value; render(); };
function reportFileName(R, ext) { return `${R.title} ${R.period.replace(/^за период /, '').replace(/^на конец дня /, 'на ')}.${ext}`.replace(/[\\/:*?"<>|]/g, '-'); }
function reportPdfHtml(R) {
  const now = new Date();
  return `<!doctype html><html lang="ru"><head><meta charset="utf-8"><style>
    *{box-sizing:border-box}body{font:11px/1.4 "Segoe UI",Arial,sans-serif;color:#1A2233;margin:0}
    .top{display:flex;justify-content:space-between;align-items:flex-end;border-bottom:2px solid #0F8A7E;padding-bottom:8px;margin-bottom:14px}
    h1{font-size:18px;margin:0}.co{font-size:12px;font-weight:600}.muted{color:#677084}
    table{border-collapse:collapse;width:100%}th{text-align:left;font-weight:600;background:#EEF2F6;padding:6px 7px;border-bottom:1px solid #9AA3B2;font-size:10.5px}
    td{padding:5px 7px;border-bottom:1px solid #E2E6EC}.n{text-align:right;white-space:nowrap}
    tfoot td{font-weight:700;border-top:1.5px solid #1A2233;border-bottom:0}tr.section td{background:#F5F7FA;font-weight:700}
    thead{display:table-header-group}tfoot{display:table-row-group}tr{page-break-inside:avoid}
    .sign{margin-top:36px;display:flex;gap:60px}.sign div{flex:1;border-top:1px solid #9AA3B2;padding-top:4px;color:#677084}
  </style></head><body>
  <div class="top"><div><div class="co">${esc(S.settings.company || 'ЭВА Склад')}</div><h1>${esc(R.title)}</h1><div class="muted">${esc(R.period)}</div></div>
  <div class="muted">Сформирован ${now.toLocaleDateString('ru-RU')} ${now.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' })}</div></div>
  ${reportTable(R)}
  <div class="sign"><div>Ответственный</div><div>Подпись</div></div></body></html>`;
}
ACT.repPdf = async () => {
  const R = buildReport(REP.id);
  if (!IS_DESKTOP) return toast('Сохранение в PDF работает в установленной программе', true);
  try {
    const path = await window.api.pdf({ html: reportPdfHtml(R), defaultName: reportFileName(R, 'pdf'), landscape: R.landscape });
    if (path) { toast('PDF сохранён'); window.api.showFile(path); }
  } catch (e) { toast('Не удалось сохранить PDF: ' + e.message, true); }
};
function reportSheet(R) {
  const style = t => ({ kg: 'dec1', int: 'int', g: 'dec1' }[t] || 'def');
  const val = (v, t) => (v === '' || v === null || v === undefined) ? '' : t === 'kg' ? Math.round(v) / 1000 : v;
  const rows = [[{ v: S.settings.company || 'ЭВА Склад', s: 'bold' }], [{ v: R.title, s: 'title' }], [{ v: R.period, s: 'muted' }], [],
    R.cols.map(c => ({ v: c.h, s: 'head' }))];
  for (const r of R.rows) {
    if (r.section) { rows.push([{ v: r.section, s: 'bold' }]); continue; }
    rows.push(r.map((v, i) => ({ v: val(v, R.cols[i].t), s: style(R.cols[i].t) })));
  }
  if (R.total && R.rows.length) rows.push(R.total.map((v, i) => ({ v: val(v, R.cols[i].t), s: { dec1: 'bdec1', int: 'bint', def: 'bold' }[style(R.cols[i].t)] })));
  return { name: R.title, columns: R.cols.map(c => ({ width: c.w })), rows, freezeRow: 5, landscape: R.landscape };
}
ACT.repXlsx = async () => {
  const R = buildReport(REP.id), bytes = XLSX.build([reportSheet(R)]), name = reportFileName(R, 'xlsx');
  if (!IS_DESKTOP) {
    const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([bytes], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' })); a.download = name; a.click();
    return toast('Файл Excel сохранён');
  }
  try {
    const path = await window.api.saveFile({ defaultName: name, filters: [{ name: 'Excel', extensions: ['xlsx'] }], data: XLSX.toBase64(bytes), encoding: 'base64' });
    if (path) { toast('Файл Excel сохранён'); window.api.showFile(path); }
  } catch (e) { toast('Не удалось сохранить Excel: ' + e.message, true); }
};

/* =====================================================================
   Справочники
   ===================================================================== */
const NEW = { art: { code: '', name: '', gpp: '', withFur: true }, rc: { name: '', hex: '#888888', minKg: '' }, fc: { name: '', hex: '#BBBBBB', minPairs: '' }, rt: { name: '' } };
const LISTS = { art: () => S.articles, rc: () => S.rawColors, fc: () => S.furColors, rt: () => S.rawTypes };
function isUsed(kind, id) {
  if (kind === 'art') return S.prod.some(p => p.articleId === id);
  if (kind === 'rc') return S.rawIn.some(r => r.colorId === id) || S.prod.some(p => p.rawColorId === id);
  if (kind === 'fc') return S.furIn.some(r => r.colorId === id) || S.prod.some(p => p.furColorId === id);
  if (kind === 'rt') return S.rawIn.some(r => r.typeId === id) || S.prod.some(p => p.typeId === id);
}
function rowActions(kind, x) {
  return isUsed(kind, x.id) ? `<button class="link" data-click="refArch" data-kind="${kind}" data-id="${x.id}">${x.archived ? 'вернуть' : 'в архив'}</button>`
    : `<button class="link danger" data-click="refDel" data-kind="${kind}" data-id="${x.id}">удалить</button>`;
}
VIEWS.ref = () => {
  const inp = (kind, x, k, cls = '', type = 'text') => `<input type="${type}" class="${cls}" value="${esc(x[k] ?? '')}" data-change="refSet" data-kind="${kind}" data-id="${x.id}" data-k="${k}">`;
  const nInp = (kind, k, cls = '', ph = '') => `<input class="${cls}" value="${esc(NEW[kind][k])}" data-input="refNew" data-kind="${kind}" data-k="${k}" placeholder="${ph}">`;
  return `<div class="page-head"><div><h1>Справочники</h1><p>Изменения сохраняются сразу. Записи, которые уже есть в документах, можно только убрать в архив.</p></div></div>
  <div class="card"><div class="card-head"><div><h2>Артикулы</h2><p>Вес пары подставляется при закрытии смены; его можно поменять прямо там.</p></div></div>
    <table class="ref-tbl"><thead><tr><th>Артикул</th><th>Наименование</th><th class="n">Вес пары, г</th><th>С мехом</th><th></th></tr></thead><tbody>
    ${S.articles.map(a => `<tr class="${a.archived ? 'archived' : ''}"><td>${inp('art', a, 'code', 'w-s')}</td><td>${inp('art', a, 'name', 'w-l')}</td><td class="n">${inp('art', a, 'gpp', 'w-s num')}</td>
      <td><label class="check"><input type="checkbox" ${a.withFur ? 'checked' : ''} data-change="refFur" data-id="${a.id}"> да</label></td><td class="n">${rowActions('art', a)}</td></tr>`).join('')}
    <tr><td>${nInp('art', 'code', 'w-s', '1801')}</td><td>${nInp('art', 'name', 'w-l', 'Тапочки женские')}</td><td class="n">${nInp('art', 'gpp', 'w-s num', '210')}</td>
      <td><label class="check"><input type="checkbox" ${NEW.art.withFur ? 'checked' : ''} data-change="refNewFur"> да</label></td><td class="n"><button class="btn pri" data-click="refAdd" data-kind="art">Добавить</button></td></tr></tbody></table></div>
  <div class="grid g-half mt">
    <div class="card"><div class="card-head"><div><h2>Цвета сырья</h2><p>Минимум — ниже него остаток подсвечивается красным</p></div></div>
      <table class="ref-tbl"><thead><tr><th></th><th>Название</th><th class="n">Минимум, кг</th><th></th></tr></thead><tbody>
      ${S.rawColors.map(c => `<tr class="${c.archived ? 'archived' : ''}"><td>${inp('rc', c, 'hex', '', 'color')}</td><td>${inp('rc', c, 'name', 'w-m')}</td><td class="n">${inp('rc', c, 'minKg', 'w-s num')}</td><td class="n">${rowActions('rc', c)}</td></tr>`).join('')}
      <tr><td><input type="color" value="${NEW.rc.hex}" data-input="refNew" data-kind="rc" data-k="hex"></td><td>${nInp('rc', 'name', 'w-m', 'Чёрный')}</td><td class="n">${nInp('rc', 'minKg', 'w-s num', '0')}</td><td class="n"><button class="btn pri" data-click="refAdd" data-kind="rc">Добавить</button></td></tr></tbody></table></div>
    <div class="card"><div class="card-head"><div><h2>Цвета меха</h2><p>Мех учитывается в парах: одна пара меха на пару обуви</p></div></div>
      <table class="ref-tbl"><thead><tr><th></th><th>Название</th><th class="n">Минимум, пар</th><th></th></tr></thead><tbody>
      ${S.furColors.map(c => `<tr class="${c.archived ? 'archived' : ''}"><td>${inp('fc', c, 'hex', '', 'color')}</td><td>${inp('fc', c, 'name', 'w-m')}</td><td class="n">${inp('fc', c, 'minPairs', 'w-s num')}</td><td class="n">${rowActions('fc', c)}</td></tr>`).join('')}
      <tr><td><input type="color" value="${NEW.fc.hex}" data-input="refNew" data-kind="fc" data-k="hex"></td><td>${nInp('fc', 'name', 'w-m', 'Серый')}</td><td class="n">${nInp('fc', 'minPairs', 'w-s num', '0')}</td><td class="n"><button class="btn pri" data-click="refAdd" data-kind="fc">Добавить</button></td></tr></tbody></table></div>
  </div>
  <div class="card mt"><div class="card-head"><div><h2>Виды сырья</h2><p>Если сырьё одного вида, оставьте одну строку — выбор вида тогда не показывается.</p></div></div>
    <table class="ref-tbl" style="max-width:520px"><tbody>
    ${S.rawTypes.map(t => `<tr class="${t.archived ? 'archived' : ''}"><td>${inp('rt', t, 'name', 'w-l')}</td><td class="n">${S.rawTypes.length > 1 ? rowActions('rt', t) : ''}</td></tr>`).join('')}
    <tr><td>${nInp('rt', 'name', 'w-l', 'ЭВА 28% VA')}</td><td class="n"><button class="btn pri" data-click="refAdd" data-kind="rt">Добавить</button></td></tr></tbody></table></div>`;
};
ACT.refNew = el => { NEW[el.dataset.kind][el.dataset.k] = el.value; };
ACT.refNewFur = el => { NEW.art.withFur = el.checked; };
ACT.refFur = el => { byId(S.articles, el.dataset.id).withFur = el.checked; save(); };
ACT.refAdd = el => {
  const kind = el.dataset.kind, n = NEW[kind], low = s => String(s).trim().toLowerCase().replace(/ё/g, 'е');
  const name = String(n.name || '').trim();
  if (kind === 'art') {
    const code = n.code.trim(), gpp = parseNum(n.gpp);
    if (!code || !name) return toast('Введите артикул и наименование', true);
    if (!(gpp > 0)) return toast('Укажите вес пары в граммах', true);
    if (S.articles.some(a => low(a.code) === low(code))) return toast('Такой артикул уже есть', true);
    S.articles.push({ id: nid(), code, name, gpp, withFur: n.withFur });
    NEW.art = { code: '', name: '', gpp: '', withFur: n.withFur };
  } else {
    if (!name) return toast('Введите название', true);
    const list = LISTS[kind]();
    if (list.some(x => low(x.name) === low(name))) return toast('Такое название уже есть', true);
    if (kind === 'rc') { S.rawColors.push({ id: nid(), name, hex: n.hex, minKg: parseNum(n.minKg) || 0 }); NEW.rc = { name: '', hex: '#888888', minKg: '' }; }
    if (kind === 'fc') { S.furColors.push({ id: nid(), name, hex: n.hex, minPairs: Math.round(parseNum(n.minPairs) || 0) }); NEW.fc = { name: '', hex: '#BBBBBB', minPairs: '' }; }
    if (kind === 'rt') { S.rawTypes.push({ id: nid(), name }); NEW.rt = { name: '' }; }
  }
  save(); render(); toast('Добавлено');
};
ACT.refSet = el => {
  const kind = el.dataset.kind, x = byId(LISTS[kind](), el.dataset.id), k = el.dataset.k;
  let v = el.value;
  if (k === 'gpp') { v = parseNum(v); if (!(v > 0)) { render(); return toast('Вес пары должен быть больше нуля', true); } }
  else if (k === 'minKg') v = Math.max(0, parseNum(v) || 0);
  else if (k === 'minPairs') v = Math.max(0, Math.round(parseNum(v) || 0));
  else if (k !== 'hex') { v = v.trim(); if (!v) { render(); return toast('Поле не может быть пустым', true); } }
  x[k] = v; save(); render();
};
ACT.refDel = el => {
  const kind = el.dataset.kind, id = +el.dataset.id;
  if (isUsed(kind, id)) return toast('Запись уже используется — её можно только убрать в архив', true);
  if (kind === 'rt' && S.rawTypes.length < 2) return toast('Должен остаться хотя бы один вид сырья', true);
  const list = LISTS[kind](); list.splice(list.findIndex(x => x.id === id), 1); save(); render();
};
ACT.refArch = el => {
  const kind = el.dataset.kind, x = byId(LISTS[kind](), el.dataset.id);
  if (kind === 'rt' && !x.archived && active(S.rawTypes).length < 2) return toast('Должен остаться хотя бы один активный вид сырья', true);
  x.archived = !x.archived; save(); render();
};

/* =====================================================================
   Настройки
   ===================================================================== */
let appInfo = null;
VIEWS.set = () => `<div class="page-head"><div><h1>Настройки</h1><p>Данные хранятся на этом компьютере. Программа сама делает копию каждый день при запуске и хранит 30 последних.</p></div></div>
  <div class="card" style="margin-bottom:18px"><div class="card-head"><div><h2>Автоматические копии в папку и на Google Диск</h2>
    <p>Копия записывается при каждом закрытии программы, а также при запуске и каждые 15 минут после изменений. В каждой папке — одна копия за день, 30 последних дней.</p></div>
    ${IS_DESKTOP ? `<div class="actions"><button class="btn" data-click="bkAddGDrive">Добавить Google Диск</button><button class="btn" data-click="bkAddFolder">Добавить папку…</button><button class="btn pri" data-click="bkRun">Сделать копию сейчас</button></div>` : ''}</div>
    <div id="bkList">${IS_DESKTOP ? bkListHtml() : '<div class="notice">Автокопии работают в установленной программе.</div>'}</div></div>
  <div class="grid g-half">
    <div class="card"><div class="card-head"><h2>Предприятие</h2></div>
      <label class="field"><span>Название — печатается в отчётах</span><input class="w-l" value="${esc(S.settings.company)}" data-change="setVal" data-k="company" placeholder="ОсОО «Название»"></label></div>
    <div class="card"><div class="card-head"><h2>Остатки</h2></div>
      <div class="fields">
        <label class="field"><span>Желаемый запас, дней</span><input type="number" min="1" class="w-s" value="${S.settings.targetDays}" data-change="setNum" data-k="targetDays"></label>
        <label class="field"><span>Средний расход считать за, дней</span><input type="number" min="1" class="w-s" value="${S.settings.avgDays}" data-change="setNum" data-k="avgDays"></label>
      </div>
      <label class="check mt"><input type="checkbox" ${S.settings.allowNegative ? 'checked' : ''} data-change="setNeg"> Разрешать проводить смену, если сырья или меха не хватает (остаток уйдёт в минус)</label></div>
    <div class="card"><div class="card-head"><div><h2>Резервная копия</h2><p>Сохраняйте копию на флешку или в облако — из неё данные восстанавливаются на любом компьютере.</p></div></div>
      <div class="actions"><button class="btn pri" data-click="backupSave">Сохранить копию в файл</button><button class="btn" data-click="backupLoad">Восстановить из копии</button>
      ${IS_DESKTOP ? '<button class="btn" data-click="openData">Открыть папку с данными</button>' : ''}</div></div>
    <div class="card"><div class="card-head"><div><h2>Пример и очистка</h2><p>Пример заполнит справочники, поступления и 10 дней выпуска. Текущие данные будут заменены.</p></div></div>
      <div class="actions"><button class="btn" data-click="demo">Загрузить пример</button><button class="btn danger" data-click="wipe">Удалить все данные</button></div>
      <p class="muted" id="verInfo">${appInfo ? `Версия ${esc(appInfo.version)} · данные: ${esc(appInfo.dataDir)}` : ''}</p></div>
  </div>`;
let BK = { cfg: null, notFound: false };
function fdt(ms) { const d = new Date(ms); return d.toLocaleDateString('ru-RU') + ' ' + d.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' }); }
const GD_ICON = '<svg viewBox="0 0 24 24" width="22" height="22" aria-hidden="true"><path d="M8.2 3.5h7.6l6 10.4h-7.6z" fill="#F2B84B"/><path d="M8.2 3.5 2.2 13.9 6 20.5l6-10.4z" fill="#0F8A7E"/><path d="M6 20.5h12l3.8-6.6H9.8z" fill="#2F6FD6"/></svg>';
const FOLDER_ICON = '<svg viewBox="0 0 24 24" width="22" height="22" aria-hidden="true"><path d="M3 6.5A1.5 1.5 0 0 1 4.5 5h4.6l2 2.2h8.4A1.5 1.5 0 0 1 21 8.7v9.8a1.5 1.5 0 0 1-1.5 1.5h-15A1.5 1.5 0 0 1 3 18.5z" fill="#D9C27A"/></svg>';
function bkListHtml() {
  let h = '';
  if (BK.notFound) h += `<div class="notice bad" style="margin-bottom:12px">Google Диск на этом компьютере не найден. Установите программу «Google Диск для компьютера» с сайта google.com/drive/download, войдите в свой аккаунт Google и снова нажмите «Добавить Google Диск».</div>`;
  if (!BK.cfg) return h + '<div class="muted">Загрузка…</div>';
  if (!BK.cfg.folders.length) return h + '<div class="empty">Папки для автокопий не выбраны. Добавьте Google Диск и, например, флешку или второй диск.</div>';
  return h + `<table><tbody>${BK.cfg.folders.map((f, i) => `<tr>
    <td style="width:34px">${f.kind === 'gdrive' ? GD_ICON : FOLDER_ICON}</td>
    <td><b>${f.kind === 'gdrive' ? 'Google Диск' : 'Папка'}</b><br><span class="muted">${esc(f.path)}</span></td>
    <td>${f.lastError ? `<span class="st crit">Ошибка</span><br><span class="muted">${esc(f.lastError)}</span>` : f.lastOk ? `<span class="st ok">Копия есть</span><br><span class="muted">последняя: ${fdt(f.lastOk)}</span>` : '<span class="st none">Ещё не копировалось</span>'}</td>
    <td class="n"><button class="link" data-click="bkOpen" data-i="${i}">открыть</button> <button class="link danger" data-click="bkRemove" data-i="${i}">убрать</button></td></tr>`).join('')}</tbody></table>`;
}
function bkRefresh(cfg) { if (cfg) BK.cfg = cfg; const e = $('#bkList'); if (e) e.innerHTML = bkListHtml(); }
function bkResultToast(cfg) {
  const bad = cfg.folders.filter(f => f.lastError);
  if (bad.length) toast(`Не удалось сохранить копию: ${bad.map(f => f.lastError).join('; ')}`, true);
  else toast(cfg.folders.length ? 'Копия сохранена во все папки' : 'Сначала добавьте папку');
}
ACT.bkAddGDrive = async () => {
  const r = await window.api.backupAddGDrive();
  if (r && r.notFound) { BK.notFound = true; return bkRefresh(); }
  BK.notFound = false; bkRefresh(r); bkResultToast(r);
};
ACT.bkAddFolder = async () => { const r = await window.api.backupAddFolder(); if (r) { bkRefresh(r); bkResultToast(r); } };
ACT.bkRun = async () => { await save(); const r = await window.api.backupRun(); bkRefresh(r); bkResultToast(r); };
ACT.bkOpen = el => { const f = BK.cfg.folders[+el.dataset.i]; if (f) window.api.openPath(f.path); };
ACT.bkRemove = async el => {
  const f = BK.cfg.folders[+el.dataset.i]; if (!f) return;
  if (!confirm('Больше не копировать в эту папку? Уже сохранённые копии останутся на месте.')) return;
  bkRefresh(await window.api.backupRemove(f.path));
};
VIEWS.set.after = () => {
  if (IS_DESKTOP) window.api.backupList().then(bkRefresh);
  if (IS_DESKTOP && !appInfo) window.api.info().then(i => { appInfo = i; const e = $('#verInfo'); if (e) e.textContent = `Версия ${i.version} · данные: ${i.dataDir}`; });
};
ACT.setVal = el => { S.settings[el.dataset.k] = el.value.trim(); save(); render(); };
ACT.setNum = el => { S.settings[el.dataset.k] = Math.max(1, parseInt(el.value, 10) || 14); save(); render(); };
ACT.setNeg = el => { S.settings.allowNegative = el.checked; save(); };
ACT.backupSave = async () => {
  const text = JSON.stringify(S, null, 1), name = `ЭВА Склад копия ${today()}.json`;
  if (IS_DESKTOP) { const p = await window.api.saveFile({ defaultName: name, filters: [{ name: 'Копия ЭВА Склад', extensions: ['json'] }], data: text }); if (p) toast('Копия сохранена'); return; }
  const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([text], { type: 'application/json' })); a.download = name; a.click(); toast('Копия сохранена');
};
ACT.backupLoad = async () => {
  let text = null;
  if (IS_DESKTOP) text = await window.api.openFile({ filters: [{ name: 'Копия ЭВА Склад', extensions: ['json'] }] });
  else text = await new Promise(res => { const i = document.createElement('input'); i.type = 'file'; i.accept = '.json'; i.onchange = () => { const f = i.files[0]; if (!f) return res(null); const r = new FileReader(); r.onload = () => res(r.result); r.readAsText(f); }; i.click(); });
  if (!text) return;
  let d; try { d = JSON.parse(text); } catch (e) { d = null; }
  if (!d || !Array.isArray(d.prod) || !Array.isArray(d.rawIn) || !Array.isArray(d.articles)) return toast('Это не файл копии ЭВА Склад', true);
  if (!confirm('Заменить текущие данные данными из копии?')) return;
  S = Object.assign(blank(), d); S.settings = Object.assign(blank().settings, d.settings || {});
  save(); render(); toast('Данные восстановлены');
};
ACT.openData = async () => { const i = appInfo || await window.api.info(); window.api.openPath(i.dataDir); };
ACT.wipe = () => {
  if (!confirm('Удалить ВСЕ данные? Сначала сохраните резервную копию.')) return;
  if (!confirm('Точно удалить? Отменить это будет нельзя.')) return;
  S = blank(); save(); go('home'); toast('Все данные удалены');
};

/* =====================================================================
   Пример данных
   ===================================================================== */
ACT.demo = () => {
  if ((S.prod.length || S.rawIn.length || S.articles.length) && !confirm('Текущие данные будут заменены примером. Продолжить?')) return;
  loadDemo(); save(); go('home'); toast('Пример загружен');
};
function loadDemo() {
  S = blank();
  S.settings.company = 'Обувной цех «Пример»';
  const rc = (name, hex, minKg) => { const x = { id: nid(), name, hex, minKg }; S.rawColors.push(x); return x.id; };
  const fc = (name, hex, minPairs) => { const x = { id: nid(), name, hex, minPairs }; S.furColors.push(x); return x.id; };
  const ar = (code, name, gpp, withFur) => { const x = { id: nid(), code, name, gpp, withFur }; S.articles.push(x); return x.id; };
  const BL = rc('Чёрный', '#2B2B2E', 300), WH = rc('Белый', '#F2F2EE', 200), GR = rc('Серый', '#9AA0A6', 200), BU = rc('Синий', '#2F5FB3', 150), PK = rc('Розовый', '#E890AE', 100), BE = rc('Бежевый', '#D8C3A0', 100);
  const fGR = fc('Серый', '#A7A9AC', 500), fBE = fc('Бежевый', '#D9C5A7', 300), fPK = fc('Розовый', '#F0B6C8', 300), fBL = fc('Чёрный', '#3A3A3D', 300);
  const W = ar('1801', 'Тапочки женские', 210, true), M = ar('1802', 'Тапочки мужские', 260, true), SB = ar('2101', 'Сабо утеплённые', 280, true), SL = ar('3001', 'Сланцы', 150, false);
  const t = today(), d = n => addDays(t, -n), T = 1;
  const sup = 'ОсОО «ПолимерТрейд»';
  [[BL, 3000], [WH, 2000], [GR, 1000], [BU, 800], [PK, 500], [BE, 600]].forEach(([c, kg], i) => addRawIn({ date: d(i < 3 ? 25 : 12), typeId: T, colorId: c, g: kg * 1000, supplier: sup, note: 'Накладная № ' + (1180 + i) }));
  [[fGR, 10000], [fBE, 4000], [fPK, 1500], [fBL, 5000]].forEach(([c, n]) => addFurIn({ date: d(20), colorId: c, pairs: n, supplier: 'ИП Асанов', note: '' }));
  for (let i = 9; i >= 0; i--) {
    if (i === 3) continue; // выходной
    const day = d(i);
    addProd({ date: day, shift: '1', articleId: W, typeId: T, rawColorId: BL, furColorId: fGR, pairs: 600, gpp: 210 });
    addProd({ date: day, shift: '1', articleId: SL, typeId: T, rawColorId: BU, furColorId: null, pairs: 400, gpp: 150 });
    if (i === 0) continue; // вторая смена сегодня ещё не закрыта
    addProd({ date: day, shift: '2', articleId: M, typeId: T, rawColorId: BL, furColorId: fBL, pairs: 350, gpp: 260 });
    addProd({ date: day, shift: '2', articleId: SL, typeId: T, rawColorId: WH, furColorId: null, pairs: 500, gpp: 150 });
    if (i % 2) addProd({ date: day, shift: '2', articleId: W, typeId: T, rawColorId: PK, furColorId: fPK, pairs: 250, gpp: 210 });
    else addProd({ date: day, shift: '2', articleId: SB, typeId: T, rawColorId: GR, furColorId: fGR, pairs: 300, gpp: 280 });
  }
}

/* =====================================================================
   Запуск
   ===================================================================== */
(async function init() {
  try {
    const text = await store.load();
    if (text) { const d = JSON.parse(text); S = Object.assign(blank(), d); S.settings = Object.assign(blank().settings, d.settings || {}); }
  } catch (e) {
    toast('Не удалось прочитать файл данных — открыта пустая база. Восстановите данные из копии в настройках.', true);
  }
  render();
})();
