// Безопасный мост между окном программы и главным процессом
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('api', {
  load: () => ipcRenderer.invoke('db:load'),
  save: text => ipcRenderer.invoke('db:save', text),
  saveFile: opts => ipcRenderer.invoke('file:save', opts),
  openFile: opts => ipcRenderer.invoke('file:open', opts),
  pdf: opts => ipcRenderer.invoke('report:pdf', opts),
  openPath: p => ipcRenderer.invoke('shell:openPath', p),
  showFile: p => ipcRenderer.invoke('shell:showFile', p),
  info: () => ipcRenderer.invoke('app:info'),
  backupList: () => ipcRenderer.invoke('backup:list'),
  backupRun: () => ipcRenderer.invoke('backup:run'),
  backupAddFolder: () => ipcRenderer.invoke('backup:addFolder'),
  backupAddGDrive: () => ipcRenderer.invoke('backup:addGDrive'),
  backupRemove: p => ipcRenderer.invoke('backup:remove', p)
});
