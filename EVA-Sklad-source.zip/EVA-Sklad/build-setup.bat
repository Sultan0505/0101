@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Сборка установщика ЭВА Склад
echo.
echo  ===============================================
echo   ЭВА Склад: сборка установщика setup.exe
echo  ===============================================
echo.
where node >nul 2>nul
if errorlevel 1 (
  echo  Не найден Node.js - он нужен только для сборки.
  echo  Пробую установить его автоматически через winget...
  winget install -e --id OpenJS.NodeJS.LTS --accept-source-agreements --accept-package-agreements
  if errorlevel 1 (
    echo.
    echo  Автоматически установить не получилось.
    echo  Скачайте Node.js LTS с сайта https://nodejs.org , установите
    echo  и снова запустите этот файл.
    pause
    exit /b 1
  )
  echo.
  echo  Node.js установлен. Закройте это окно и запустите этот файл ещё раз.
  pause
  exit /b 0
)
echo  [1/2] Загружаю компоненты, это займёт несколько минут...
call npm install --no-audit --no-fund
if errorlevel 1 goto fail
echo.
echo  [2/2] Собираю установщик...
call npm run dist
if errorlevel 1 goto fail
echo.
echo  ГОТОВО. Установщик лежит в папке dist - файл EVA-Sklad-Setup-1.1.1.exe
start "" "%~dp0dist"
pause
exit /b 0
:fail
echo.
echo  Сборка не удалась. Проверьте интернет и запустите файл ещё раз.
echo  Если ошибка повторяется, пришлите текст из этого окна.
pause
exit /b 1
