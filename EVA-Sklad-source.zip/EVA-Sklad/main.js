// ЭВА Склад — главный процесс Electron
const { app, BrowserWindow, ipcMain, dialog, shell, Menu } = require('electron');
const path = require('path');
const fs = require('fs');

const DATA_DIR = () => app.getPath('userData');
const DATA_FILE = () => path.join(DATA_DIR(), 'data.json');
const BACKUP_DIR = () => path.join(DATA_DIR(), 'backups');
const KEEP_BACKUPS = 30;

let win = null;

// Русский интерфейс системных элементов (календарь, даты дд.мм.гггг)
app.commandLine.appendSwitch('lang', 'ru-RU');

// Только один экземпляр программы, чтобы два окна не записывали данные одновременно
if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.on('second-instance', () => {
    if (win) { if (win.isMinimized()) win.restore(); win.focus(); }
  });
}

function today() {
  const d = new Date();
  const p = n => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}

function readData() {
  try {
    if (!fs.existsSync(DATA_FILE())) return null;
    return fs.readFileSync(DATA_FILE(), 'utf8');
  } catch (e) {
    return null;
  }
}

// Атомарная запись: сначала во временный файл, затем переименование
function writeData(text) {
  fs.mkdirSync(DATA_DIR(), { recursive: true });
  const tmp = DATA_FILE() + '.tmp';
  fs.writeFileSync(tmp, text, 'utf8');
  // Предыдущая версия файла сохраняется рядом — на случай сбоя
  if (fs.existsSync(DATA_FILE())) fs.copyFileSync(DATA_FILE(), DATA_FILE() + '.prev');
  fs.renameSync(tmp, DATA_FILE());
}

// Ежедневная автокопия при запуске, хранится 30 последних
function dailyBackup() {
  try {
    if (!fs.existsSync(DATA_FILE())) return;
    fs.mkdirSync(BACKUP_DIR(), { recursive: true });
    const target = path.join(BACKUP_DIR(), `data-${today()}.json`);
    if (!fs.existsSync(target)) fs.copyFileSync(DATA_FILE(), target);
    const files = fs.readdirSync(BACKUP_DIR()).filter(f => /^data-\d{4}-\d{2}-\d{2}\.json$/.test(f)).sort();
    while (files.length > KEEP_BACKUPS) fs.unlinkSync(path.join(BACKUP_DIR(), files.shift()));
  } catch (e) { /* копия не критична для работы */ }
}

/* ---------- Автокопии в выбранные папки (в том числе Google Диск) ---------- */
// Настройки хранятся отдельно от данных: пути к папкам свои на каждом компьютере
const CONFIG_FILE = () => path.join(DATA_DIR(), 'backup-folders.json');
const EXT_KEEP = 30;                      // копий в каждой папке (по одной за день)
const AUTO_EVERY_MS = 15 * 60 * 1000;     // проверка изменений каждые 15 минут
const EXT_NAME = d => `ЭВА Склад копия ${d}.json`;
const EXT_RE = /^ЭВА Склад копия \d{4}-\d{2}-\d{2}\.json$/;
const GDRIVE_SUBFOLDER = 'ЭВА Склад копии';
let dirty = false;

function loadCfg() {
  try {
    const c = JSON.parse(fs.readFileSync(CONFIG_FILE(), 'utf8'));
    if (Array.isArray(c.folders)) return c;
  } catch (e) { /* ещё нет настроек */ }
  return { folders: [] };
}
function saveCfg(c) {
  fs.mkdirSync(DATA_DIR(), { recursive: true });
  fs.writeFileSync(CONFIG_FILE(), JSON.stringify(c, null, 1), 'utf8');
}
function copyToFolder(folder) {
  if (!fs.existsSync(DATA_FILE())) throw new Error('пока нечего копировать — данных нет');
  if (!fs.existsSync(folder)) throw new Error('папка недоступна (диск отключён или папка удалена)');
  const target = path.join(folder, EXT_NAME(today()));
  const tmp = target + '.tmp';
  fs.copyFileSync(DATA_FILE(), tmp);
  fs.renameSync(tmp, target);
  const old = fs.readdirSync(folder).filter(f => EXT_RE.test(f)).sort();
  while (old.length > EXT_KEEP) fs.unlinkSync(path.join(folder, old.shift()));
  return target;
}
function runBackups() {
  const cfg = loadCfg();
  for (const f of cfg.folders) {
    f.lastTry = Date.now();
    try { copyToFolder(f.path); f.lastOk = Date.now(); f.lastError = ''; }
    catch (e) { f.lastError = e.message || String(e); }
  }
  if (cfg.folders.length) saveCfg(cfg);
  dirty = false;
  return cfg;
}
function cfgView() {
  const cfg = loadCfg();
  cfg.folders.forEach(f => { f.exists = fs.existsSync(f.path); });
  return cfg;
}
function addFolder(p, kind) {
  const cfg = loadCfg();
  if (!cfg.folders.some(f => path.resolve(f.path).toLowerCase() === path.resolve(p).toLowerCase())) {
    cfg.folders.push({ path: p, kind, added: Date.now() });
    saveCfg(cfg);
  }
  runBackups();
  return cfgView();
}
// Папка Google Диска для компьютера: обычно G:\Мой диск или G:\My Drive
function findGoogleDrive() {
  const names = ['Мой диск', 'My Drive'], cands = [];
  if (process.platform === 'win32') {
    for (const L of 'GDEFHIJKLMNOPQRSTUVWXYZ') for (const n of names) cands.push(`${L}:\\${n}`);
  }
  const home = app.getPath('home');
  for (const n of names) { cands.push(path.join(home, 'Google Drive', n)); cands.push(path.join(home, n)); }
  cands.push(path.join(home, 'Google Drive'));
  for (const c of cands) {
    try { if (fs.existsSync(c) && fs.statSync(c).isDirectory()) return c; } catch (e) { /* диск недоступен */ }
  }
  return null;
}

ipcMain.handle('backup:list', () => cfgView());
ipcMain.handle('backup:run', () => { runBackups(); return cfgView(); });
ipcMain.handle('backup:addFolder', async () => {
  const r = await dialog.showOpenDialog(win, { title: 'Папка для автокопий', properties: ['openDirectory', 'createDirectory'] });
  if (r.canceled || !r.filePaths.length) return null;
  return addFolder(r.filePaths[0], 'folder');
});
ipcMain.handle('backup:addGDrive', () => {
  const root = findGoogleDrive();
  if (!root) return { notFound: true };
  const p = path.join(root, GDRIVE_SUBFOLDER);
  fs.mkdirSync(p, { recursive: true });
  return addFolder(p, 'gdrive');
});
ipcMain.handle('backup:remove', (_e, p) => {
  const cfg = loadCfg();
  cfg.folders = cfg.folders.filter(f => f.path !== p);
  saveCfg(cfg);
  return cfgView();
});

function createWindow() {
  win = new BrowserWindow({
    width: 1360,
    height: 860,
    minWidth: 1100,
    minHeight: 680,
    title: 'ЭВА Склад',
    backgroundColor: '#F2F4F7',
    icon: path.join(__dirname, 'build', 'icon.ico'),
    show: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      spellcheck: false
    }
  });
  Menu.setApplicationMenu(null);
  win.loadFile(path.join(__dirname, 'renderer', 'index.html'));
  win.once('ready-to-show', () => { win.maximize(); win.show(); });
  // Выключение или перезагрузка Windows при открытой программе — тоже делаем копию
  win.on('session-end', () => backupOnClose());
  // Внешние ссылки открываются в браузере, а не внутри программы
  win.webContents.setWindowOpenHandler(({ url }) => { shell.openExternal(url); return { action: 'deny' }; });
}

ipcMain.handle('db:load', () => readData());
ipcMain.handle('db:save', (_e, text) => { writeData(text); dirty = true; return true; });

ipcMain.handle('file:save', async (_e, { defaultName, filters, data, encoding }) => {
  const r = await dialog.showSaveDialog(win, { defaultPath: defaultName, filters });
  if (r.canceled || !r.filePath) return null;
  const buf = encoding === 'base64' ? Buffer.from(data, 'base64') : Buffer.from(data, 'utf8');
  fs.writeFileSync(r.filePath, buf);
  return r.filePath;
});

ipcMain.handle('file:open', async (_e, { filters }) => {
  const r = await dialog.showOpenDialog(win, { properties: ['openFile'], filters });
  if (r.canceled || !r.filePaths.length) return null;
  return fs.readFileSync(r.filePaths[0], 'utf8');
});

// PDF: отчёт рендерится в скрытом окне и печатается в файл
ipcMain.handle('report:pdf', async (_e, { html, defaultName, landscape }) => {
  const r = await dialog.showSaveDialog(win, { defaultPath: defaultName, filters: [{ name: 'PDF', extensions: ['pdf'] }] });
  if (r.canceled || !r.filePath) return null;
  const pdfWin = new BrowserWindow({ show: false, webPreferences: { sandbox: true, contextIsolation: true } });
  try {
    await pdfWin.loadURL('data:text/html;charset=utf-8;base64,' + Buffer.from(html, 'utf8').toString('base64'));
    const pdf = await pdfWin.webContents.printToPDF({
      pageSize: 'A4',
      landscape: !!landscape,
      printBackground: true,
      margins: { top: 0.5, bottom: 0.5, left: 0.5, right: 0.5 }
    });
    fs.writeFileSync(r.filePath, pdf);
  } finally {
    pdfWin.destroy();
  }
  return r.filePath;
});

ipcMain.handle('shell:openPath', (_e, p) => shell.openPath(p));
ipcMain.handle('shell:showFile', (_e, p) => { shell.showItemInFolder(p); return true; });
ipcMain.handle('app:info', () => ({ version: app.getVersion(), dataDir: DATA_DIR(), backupDir: BACKUP_DIR() }));

app.whenReady().then(() => {
  dailyBackup();
  try { runBackups(); } catch (e) { /* не мешаем запуску */ }
  setInterval(() => { if (dirty) { try { runBackups(); } catch (e) { /* повторим позже */ } } }, AUTO_EVERY_MS);
  createWindow();
});

// При закрытии программы — всегда свежая копия: в локальную папку backups и во все выбранные папки
let closingBackupDone = false;
function backupOnClose() {
  if (closingBackupDone) return;
  closingBackupDone = true;
  try {
    if (fs.existsSync(DATA_FILE())) {
      fs.mkdirSync(BACKUP_DIR(), { recursive: true });
      fs.copyFileSync(DATA_FILE(), path.join(BACKUP_DIR(), `data-${today()}.json`));
    }
  } catch (e) { /* закрываемся в любом случае */ }
  try { runBackups(); } catch (e) { /* закрываемся в любом случае */ }
}
app.on('before-quit', backupOnClose);

app.on('window-all-closed', () => app.quit());
