@echo off
chcp 65001 >nul
cd /d "%~dp0"
title ЭВА Склад - запуск без установки
where node >nul 2>nul
if errorlevel 1 (
  echo Сначала запустите build-setup.bat - он установит всё нужное.
  pause
  exit /b 1
)
if not exist node_modules (
  echo Загружаю компоненты...
  call npm install --no-audit --no-fund
)
call npm start
